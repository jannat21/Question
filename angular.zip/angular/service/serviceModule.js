(function () {
    "use strict";
    angular.module('serviceModule', []);
}());

